import { useLocation } from 'wouter';
import Navigation from '@/components/Navigation';
import { trpc } from '@/lib/trpc';
import { Loader2, Trash2, ChefHat } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { toast } from 'sonner';
import type { AIHistoryRecord } from '@shared/types';

export default function AIHistory() {
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();

  const historyQuery = trpc.recipe.aiHistory.list.useQuery({ limit: 50 });

  const deleteMutation = trpc.recipe.aiHistory.delete.useMutation({
    onSuccess: () => {
      toast.success('History item deleted');
      utils.recipe.aiHistory.list.invalidate();
    },
    onError: () => {
      toast.error('Failed to delete history item');
    },
  });

  const handleSearch = (query: string) => {
    setLocation(`/search?q=${encodeURIComponent(query)}`);
  };

  const handleDelete = (historyId: number) => {
    if (confirm('Delete this history item?')) {
      deleteMutation.mutate({ historyId });
    }
  };

  if (historyQuery.isLoading) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Navigation onSearch={handleSearch} />
        <div className="flex-1 flex items-center justify-center">
          <div className="flex flex-col items-center gap-4">
            <Loader2 className="w-12 h-12 text-accent animate-spin" />
            <p className="text-muted-foreground font-lato">Loading history...</p>
          </div>
        </div>
      </div>
    );
  }

  if (historyQuery.isError) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Navigation onSearch={handleSearch} />
        <div className="flex-1 flex items-center justify-center">
          <div className="flex flex-col items-center gap-4">
            <p className="text-destructive font-lato text-lg">Failed to load history</p>
            <Button
              onClick={() => historyQuery.refetch()}
              className="bg-accent text-accent-foreground hover:bg-accent/90"
            >
              Retry
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const history = historyQuery.data || [];

  return (
    <div className="min-h-screen bg-background">
      <Navigation onSearch={handleSearch} />

      <div className="container py-12">
        <div className="mb-12">
          <h1 className="font-merriweather font-bold text-4xl text-accent mb-2">
            AI Recognition History
          </h1>
          <p className="text-muted-foreground font-lato">
            Your AI ingredient recognition and recipe recommendation history
          </p>
        </div>

        {history.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20">
            <ChefHat className="w-16 h-16 text-muted-foreground mb-4 opacity-50" />
            <p className="text-muted-foreground font-lato text-lg mb-4">
              No recognition history yet
            </p>
            <Button onClick={() => setLocation('/ai-recognition')} variant="outline">
              Start AI Recognition
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {history.map((item: AIHistoryRecord) => (
              <Card key={item.id} className="recipe-card p-6 space-y-4">
                <div className="relative h-48 overflow-hidden rounded-lg bg-muted">
                  <img
                    src={item.imageUrl}
                    alt="Recognition"
                    className="w-full h-full object-cover"
                  />
                </div>

                <div>
                  <h3 className="font-merriweather font-bold text-accent mb-2">
                    Recognized Ingredients
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {item.recognizedIngredients.map((ingredient) => (
                      <span
                        key={`${ingredient.name}-${ingredient.quantity}-${ingredient.unit}`}
                        className="ingredient-tag accent text-sm"
                      >
                        {ingredient.name}
                      </span>
                    ))}
                  </div>
                </div>

                {item.recommendedRecipes.length > 0 && (
                  <div>
                    <h3 className="font-merriweather font-bold text-accent mb-2">
                      Recommended Recipes
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {item.recommendedRecipes.slice(0, 3).map(recipe => (
                        <span key={recipe} className="ingredient-tag text-sm">
                          {recipe}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                <div className="text-xs text-muted-foreground font-lato">
                  {new Date(item.createdAt).toLocaleDateString()} {new Date(item.createdAt).toLocaleTimeString()}
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => {
                      const ingredients = item.recognizedIngredients
                        .map((ingredient) => ingredient.name)
                        .join(', ');
                      setLocation(`/search?q=${encodeURIComponent(ingredients)}`);
                    }}
                    variant="outline"
                    size="sm"
                    className="flex-1"
                  >
                    Search Recipes
                  </Button>
                  <Button
                    onClick={() => handleDelete(item.id)}
                    disabled={deleteMutation.isPending}
                    variant="ghost"
                    size="sm"
                    className="text-destructive hover:text-destructive"
                  >
                    {deleteMutation.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      <footer className="border-t border-border bg-secondary/50 py-8 mt-16">
        <div className="container text-center text-muted-foreground text-sm font-lato">
          <p>Recipe Finder Pro - Your culinary companion</p>
        </div>
      </footer>
    </div>
  );
}
