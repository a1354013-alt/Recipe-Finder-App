/**
 * Request ID 中間件
 * 
 * 功能：
 * - 為每個 request 分配唯一的 requestId
 * - 優先使用 client 帶來的 x-request-id
 * - 將 requestId 存入 req.id（供後續中間件和路由使用）
 * - 將 requestId 存入 response header（方便前端追蹤）
 */

import { Request, Response, NextFunction } from "express";
import { randomUUID } from "crypto";

export function requestIdMiddleware(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // 優先使用 client 帶來的 x-request-id，否則生成新的
  const requestId = (req.headers["x-request-id"] as string) || randomUUID();
  
  // 存入 req 物件供後續使用
  (req as any).id = requestId;
  
  // 設定 response header
  res.setHeader("x-request-id", requestId);
  
  next();
}

/**
 * 擴展 Express Request 型別
 */
declare global {
  namespace Express {
    interface Request {
      id?: string;
    }
  }
}
