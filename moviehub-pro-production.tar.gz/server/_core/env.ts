/**
 * 環境變數配置
 * 
 * 特性：
 * - 統一管理所有環境變數
 * - Production 環境啟動時驗證必填項
 * - 提供 isProduction 標誌
 * - 環境變數優先級：優先讀 server runtime 變數，fallback Vite 注入變數
 */

export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  // 優先讀 OAUTH_PORTAL_URL（server runtime），fallback VITE_OAUTH_PORTAL_URL（Vite 注入）
  oAuthPortalUrl: process.env.OAUTH_PORTAL_URL ?? process.env.VITE_OAUTH_PORTAL_URL ?? "",
  postLoginRedirect: process.env.POST_LOGIN_REDIRECT ?? "/",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
};

/**
 * 驗證必填環境變數
 * 
 * Production 環境啟動時必須檢查這些變數
 * 缺少任何一個都會直接 throw，fail fast
 */
export function validateRequiredEnv(): void {
  const requiredEnvs = [
    { key: "VITE_APP_ID", value: ENV.appId },
    { key: "JWT_SECRET", value: ENV.cookieSecret },
    { key: "DATABASE_URL", value: ENV.databaseUrl },
    { key: "OAUTH_SERVER_URL", value: ENV.oAuthServerUrl },
    { key: "OAUTH_PORTAL_URL (or VITE_OAUTH_PORTAL_URL)", value: ENV.oAuthPortalUrl },
    { key: "BUILT_IN_FORGE_API_URL", value: ENV.forgeApiUrl },
    { key: "BUILT_IN_FORGE_API_KEY", value: ENV.forgeApiKey },
  ];

  const missing: string[] = [];

  for (const { key, value } of requiredEnvs) {
    if (!value || value.trim() === "") {
      missing.push(key);
    }
  }

  if (missing.length > 0) {
    const message = `Missing required environment variables: ${missing.join(", ")}`;
    console.error(`[ENV] ${message}`);
    throw new Error(message);
  }
}
