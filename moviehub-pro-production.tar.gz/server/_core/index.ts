import express from "express";
import { createServer } from "http";
import net from "net";
import cookieParser from "cookie-parser";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { ENV, validateRequiredEnv } from "./env";
import { logger } from "./logger";
import { closePool } from "../db";
import { requestIdMiddleware } from "./requestId";

/**
 * 檢查 port 是否可用
 */
function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

/**
 * 尋找可用 port（僅用於開發環境）
 */
async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

/**
 * 啟動伺服器
 * 
 * 邏輯：
 * - Development：如果指定 port 被佔用，自動尋找可用 port
 * - Production：如果指定 port 被佔用，直接 fail（fail fast）
 */
async function startServer() {
  try {
    // Production 環境驗證必填環境變數
    if (ENV.isProduction) {
      logger.info("[Server] Validating required environment variables");
      validateRequiredEnv();
      logger.info("[Server] Environment variables validation passed");
    }

    const app = express();
    const server = createServer(app);

    // Trust proxy (for Nginx, Cloudflare, etc.)
    app.set("trust proxy", 1);

    // Request ID middleware (must be first to track all requests)
    app.use(requestIdMiddleware);

    // Cookie parser middleware (must be before routes that use cookies)
    app.use(cookieParser());

    // Configure body parser with larger size limit for file uploads
    app.use(express.json({ limit: "50mb" }));
    app.use(express.urlencoded({ limit: "50mb", extended: true }));

    // OAuth callback under /api/oauth/callback
    registerOAuthRoutes(app);

    // tRPC API
    app.use(
      "/api/trpc",
      createExpressMiddleware({
        router: appRouter,
        createContext,
      })
    );

    // development mode uses Vite, production mode uses static files
    if (process.env.NODE_ENV === "development") {
      await setupVite(app, server);
    } else {
      serveStatic(app);
    }

    // Global error handler (MUST be after all routes and middleware)
    app.use((err: any, req: any, res: any, next: any) => {
      if (res.headersSent) {
        logger.debug(
          "[Error] Headers already sent",
          { message: err?.message },
          req.id
        );
        return next(err);
      }

      const requestId = req.id;
      const statusCode = err?.statusCode || err?.status || 500;
      const message = err?.message || "Internal server error";

      logger.error(
        "[Error] Unhandled error",
        { statusCode, message: message.substring(0, 100) },
        requestId
      );

      res.status(statusCode).json({
        error: message,
        requestId,
        ...(ENV.isProduction ? {} : { stack: err?.stack }),
      });
    });

    const preferredPort = parseInt(process.env.PORT || "3000");

    // Development：尋找可用 port
    // Production：使用指定 port，不可用則 fail
    let port: number;
    if (ENV.isProduction) {
      // Production：檢查 port 是否可用，不可用則拒絕啟動
      const available = await isPortAvailable(preferredPort);
      if (!available) {
        const error = `Port ${preferredPort} is not available in production environment. Fail fast.`;
        logger.error("[Server] Port not available", error);
        throw new Error(error);
      }
      port = preferredPort;
    } else {
      // Development：自動尋找可用 port
      port = await findAvailablePort(preferredPort);
      if (port !== preferredPort) {
        logger.warn("[Server] Port busy", `Port ${preferredPort} is busy, using port ${port} instead`);
      }
    }

    // 優雅關閉處理
    process.on("SIGTERM", async () => {
      logger.info("[Server] SIGTERM received, shutting down gracefully");
      server.close(async () => {
        await closePool();
        logger.info("[Server] Server closed");
        process.exit(0);
      });
    });

    process.on("SIGINT", async () => {
      logger.info("[Server] SIGINT received, shutting down gracefully");
      server.close(async () => {
        await closePool();
        logger.info("[Server] Server closed");
        process.exit(0);
      });
    });

    server.listen(port, () => {
      const protocol = ENV.isProduction ? "https" : "http";
      logger.info("[Server] Server started", `Server running on ${protocol}://localhost:${port}/`);
    });
  } catch (error) {
    logger.error("[Server] Failed to start server", error);
    process.exit(1);
  }
}

startServer();
// Process 層級的錯誤處理
process.on("unhandledRejection", (reason: unknown) => {
  logger.error(
    "[Process] Unhandled rejection",
    reason instanceof Error ? reason.message : String(reason)
  );
  if (ENV.isProduction) {
    process.exit(1);
  }
});

process.on("uncaughtException", (error: Error) => {
  logger.error(
    "[Process] Uncaught exception",
    error.message
  );
  process.exit(1);
});
