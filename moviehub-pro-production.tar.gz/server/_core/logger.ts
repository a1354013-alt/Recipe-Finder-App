/**
 * 統一日誌系統
 * 
 * 特性：
 * - 四個等級：debug / info / warn / error
 * - 時間戳記（ISO 8601）
 * - 標籤前綴（便於搜尋）
 * - 支援 requestId 和 userId 追蹤
 * - Production 環境只輸出 warn 和 error
 * - 結構化日誌（便於解析）
 * - message 支援 string | object（自動轉換）
 */

type LogLevel = "debug" | "info" | "warn" | "error";

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  tag: string;
  message: string;
  requestId?: string;
  userId?: string;
  data?: Record<string, unknown>;
}

class Logger {
  private isDevelopment = process.env.NODE_ENV !== "production";

  private formatLog(entry: LogEntry): string {
    const { timestamp, level, tag, message, requestId, userId, data } = entry;
    const levelUpper = level.toUpperCase().padEnd(5);
    
    // 構建追蹤資訊
    let tracking = "";
    if (requestId) tracking += ` [rid:${requestId}]`;
    if (userId) tracking += ` [uid:${userId}]`;
    
    const dataStr = data ? ` ${JSON.stringify(data)}` : "";
    return `[${timestamp}] [${levelUpper}] ${tag} ${message}${tracking}${dataStr}`;
  }

  /**
   * 內部 log 方法
   */
  private log(
    level: LogLevel,
    tag: string,
    message: string,
    data?: Record<string, unknown>,
    requestId?: string,
    userId?: string
  ): void {
    // Production 環境只輸出 warn 和 error
    if (!this.isDevelopment && (level === "info" || level === "debug")) {
      return;
    }

    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      tag,
      message,
      data,
    };
    
    if (requestId) entry.requestId = requestId;
    if (userId) entry.userId = userId;

    const formatted = this.formatLog(entry);

    // 使用 console 的不同方法
    switch (level) {
      case "debug":
        console.log(formatted);
        break;
      case "info":
        console.log(formatted);
        break;
      case "warn":
        console.warn(formatted);
        break;
      case "error":
        console.error(formatted);
        break;
    }
  }

  /**
   * 統一的日誌方法簽名
   * message 支援 string | object
   * 如果 message 是 object，自動移到 data 參數
   */
  private normalizeArgs(
    message: string | Record<string, unknown> | undefined,
    data?: Record<string, unknown>,
    requestId?: string,
    userId?: string
  ): {
    message: string;
    data?: Record<string, unknown>;
    requestId?: string;
    userId?: string;
  } {
    let normalizedMessage = "";
    let normalizedData = data;

    if (typeof message === "string") {
      normalizedMessage = message;
    } else if (typeof message === "object" && message !== null) {
      // 如果 message 是 object，轉成 data
      normalizedData = { ...message, ...data };
      normalizedMessage = "";
    }

    return {
      message: normalizedMessage,
      data: normalizedData,
      requestId,
      userId,
    };
  }

  debug(
    tag: string,
    message?: string | Record<string, unknown>,
    data?: Record<string, unknown>,
    requestId?: string,
    userId?: string
  ): void {
    const { message: msg, data: d, requestId: rid, userId: uid } = this.normalizeArgs(
      message,
      data,
      requestId,
      userId
    );
    this.log("debug", tag, msg, d, rid, uid);
  }

  info(
    tag: string,
    message?: string | Record<string, unknown>,
    data?: Record<string, unknown>,
    requestId?: string,
    userId?: string
  ): void {
    const { message: msg, data: d, requestId: rid, userId: uid } = this.normalizeArgs(
      message,
      data,
      requestId,
      userId
    );
    this.log("info", tag, msg, d, rid, uid);
  }

  warn(
    tag: string,
    message?: string | Record<string, unknown>,
    data?: Record<string, unknown>,
    requestId?: string,
    userId?: string
  ): void {
    const { message: msg, data: d, requestId: rid, userId: uid } = this.normalizeArgs(
      message,
      data,
      requestId,
      userId
    );
    this.log("warn", tag, msg, d, rid, uid);
  }

  error(
    tag: string,
    message?: string | Record<string, unknown> | Error,
    data?: Record<string, unknown>,
    requestId?: string,
    userId?: string
  ): void {
    let msg = "";
    let d = data;

    if (typeof message === "string") {
      msg = message;
    } else if (message instanceof Error) {
      msg = message.message;
      d = { ...d, stack: message.stack };
    } else if (typeof message === "object" && message !== null) {
      d = { ...message, ...data };
      msg = "";
    }

    this.log("error", tag, msg, d, requestId, userId);
  }
}

export const logger = new Logger();
