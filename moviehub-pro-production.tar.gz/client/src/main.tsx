import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { httpBatchLink, TRPCClientError } from "@trpc/client";
import superjson from "superjson";
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import { trpc } from './lib/trpc'
import './index.css'

/**
 * 自訂 retry 邏輯：
 * - 401 (UNAUTHORIZED) 不重試（未登入）
 * - 其他錯誤最多重試 2 次
 */
function shouldRetry(failureCount: number, error: unknown): boolean {
  // 檢查是否為 401 UNAUTHORIZED
  if (error instanceof TRPCClientError) {
    if (error.data?.code === "UNAUTHORIZED") {
      return false;
    }
  }

  // 其他錯誤最多重試 2 次
  return failureCount < 2;
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: shouldRetry,
      staleTime: 1000 * 60 * 5, // 5 minutes
      gcTime: 1000 * 60 * 10, // 10 minutes
    },
    mutations: {
      retry: shouldRetry,
    },
  },
});

const trpcClient = trpc.createClient({
  transformer: superjson,
  links: [
    httpBatchLink({
      url: "/api/trpc",
      fetch(input, init) {
        return globalThis.fetch(input, {
          ...(init ?? {}),
          credentials: "include",
        });
      },
    }),
  ],
});

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <trpc.Provider client={trpcClient} queryClient={queryClient}>
        <App />
      </trpc.Provider>
    </QueryClientProvider>
  </React.StrictMode>,
)
